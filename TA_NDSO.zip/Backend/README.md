# Backend
This module defines the Data Warehousing application logic and it defines all REST endpoints.
It uses swagger and express.
Look up the api/swagger/swagger.yaml for the api definition and
at api/controllers for the implementation.
