# Persistence
The src folder contains the database artifact definitions.
Of special importance for Data WareHousing projects are native
datastore objects (NDSO) that are part of CDS artifacts and
FlowGraphs.

The namespace is defined in the file: .hdinamespace.
In SAP Web IDE you can view this by view-> show hidden files.
