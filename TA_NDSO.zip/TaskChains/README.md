# Task chains
The src folder contains the task chain definitions.
The namespace is defined in the file: .dwfnamespace.
In SAP Web IDE, you can view this by view-> show hidden files.
