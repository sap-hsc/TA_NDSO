This folder is supposed to contain further configurations
of the TaskChains defined in the ../src folder.
E.g. please not, currently nothing is supported, nevertheless
you need this cfg folder.
